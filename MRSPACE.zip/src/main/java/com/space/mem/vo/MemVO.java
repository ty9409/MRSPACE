package com.space.mem.vo;

import com.space.memlogin.vo.LoginVO;

import lombok.Data;

@Data
public class MemVO extends LoginVO {

	private String mem_Num;
	private String mem_OldPw;
	private String mem_Birth;
	private String mem_Phone;
	private String mem_Email;
	private String mem_Job;
	private String mem_Date;
	private String mem_Use;
	private String mem_State;

	public String getMem_Num() {
		return mem_Num;
	}

	public void setMem_Num(String mem_Num) {
		this.mem_Num = mem_Num;
	}

	public String getMem_OldPw() {
		return mem_OldPw;
	}

	public void setMem_OldPw(String mem_OldPw) {
		this.mem_OldPw = mem_OldPw;
	}

	public String getMem_Birth() {
		return mem_Birth;
	}

	public void setMem_Birth(String mem_Birth) {
		this.mem_Birth = mem_Birth;
	}

	public String getMem_Phone() {
		return mem_Phone;
	}

	public void setMem_Phone(String mem_Phone) {
		this.mem_Phone = mem_Phone;
	}

	public String getMem_Email() {
		return mem_Email;
	}

	public void setMem_Email(String mem_Email) {
		this.mem_Email = mem_Email;
	}

	public String getMem_Job() {
		return mem_Job;
	}

	public void setMem_Job(String mem_Job) {
		this.mem_Job = mem_Job;
	}

	public String getMem_Date() {
		return mem_Date;
	}

	public void setMem_Date(String mem_Date) {
		this.mem_Date = mem_Date;
	}

	public String getMem_Use() {
		return mem_Use;
	}

	public void setMem_Use(String mem_Use) {
		this.mem_Use = mem_Use;
	}

	public String getMem_State() {
		return mem_State;
	}

	public void setMem_State(String mem_State) {
		this.mem_State = mem_State;
	}

}
package com.space.admin.vo;

import lombok.Data;

@Data
public class AdminLoginVO {
	private String adminId;
	private String adminPw;
}

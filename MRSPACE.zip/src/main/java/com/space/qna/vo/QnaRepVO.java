package com.space.qna.vo;

import lombok.Data;

@Data
public class QnaRepVO extends QnaVO {
	private int rep_num;
	private String rep_content;
	private String rep_date;
	
	private int qna_Num;
	private String rep_name;
	
	

}
